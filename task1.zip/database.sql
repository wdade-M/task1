SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


-- --------------------------------------------------------

--
-- جدول المحركات  `motors`
--

CREATE TABLE `motors` (
  `m1` int(11) NOT NULL,
  `m2` int(11) NOT NULL,
  `m3` int(11) NOT NULL,
  `m4` int(11) NOT NULL,
  `m5` int(11) NOT NULL,
  `m6` int(11) NOT NULL,
  `save` boolean DEFAULT false,
  `Run` boolean DEFAULT false,
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
-

INSERT INTO `motors` (`m1`, `m2`, `m3`, `m4`, `m5`,`m6`) VALUES(1,2,3,4,5,6);  <-- هنا ضفنا القيم-->

