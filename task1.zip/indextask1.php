<?php 
    session_start();
    include('database_connect.php');


?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="style.css">
</head>
<body>

    <div class="continer">
        <label >1محرك</label>
   <div class="s">

       <input type="range" min="0" max="100" class="slider" id="range1">
       <span id="range">50</span>
   </div>
   <label >2محرك</label>
   <div class="s">
    <input type="range" min="0" max="100" class="slider"  id="range2">
    <span id="range">50</span>
</div>
<label >3محرك</label>
<div class="s">
    <input type="range" min="0" max="100" class="slider"  id="range3">
    <span id="range">50</span>
</div>
<label >4محرك</label>
<div class="s">
    <input type="range" min="0" max="100" class="slider"  id="range4">
    <span id="range">50</span>
</div>
<label >5محرك</label>
<div class="s">
    <input type="range" min="0" max="100" class="slider"  id="range5">
    <span id="range">50</span>
</div>

<label >6محرك</label>
<div class="s">
    <input type="range" min="0" max="100"  class="slider"  id="range6">
    <span id="range" >50</span>
</div> <!---->

 </div>
   <br>
   <form action='save.php' method='post'>
   <input type="submit" name ="save" value="SAVE">

</form>
<br>
<form name="forArm2" method="POST" action="run.php" >
    <button type="submit" name="run" id="run" value="run"> Run</button>

</form>
    <script src="main.js"> </script>
</body>
</html>