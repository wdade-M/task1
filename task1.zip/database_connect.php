<?php

$servername = "localhost";
$username   = "root";
$password   = "";
$dbname     = "motors";


$conn = new mysqli($servername , $username, $password, $dbname);

if ($conn->connect_error) {
  die("توجد مشكله في الاتصال " . $conn->connect_error);
}
else{
    echo" تم الاتصال بنجاح <br><br>";
    
}



?>
