const sliders =document.querySelectorAll('.s');

sliders.forEach(slider=>{

    slider.addEventListener('input' ,()=>{
        slider.lastElementChild.innerHTML =slider.firstElementChild.value
        
    })
})


